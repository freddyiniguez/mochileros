<?php
/**
 * @package WordPress
 * @subpackage Traveler
 * @since 1.0
 *
 * Email footer
 *
 * Created by ShineTheme
 *
 */
?>
</table>
</div>