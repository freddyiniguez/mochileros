<?php
/**
 * Created by PhpStorm.
 * User: me664
 * Date: 3/4/15
 * Time: 2:57 PM
 */
?>
<style>.vc_custom_1422588044061{margin-bottom: 30px !important;}</style>
<?php
echo do_shortcode('[vc_row row_fullwidth="no" parallax_class="no" bg_video="no" css=".vc_custom_1422588044061{margin-bottom: 30px !important;}"][vc_column width="1/4" el_class="col-sm2-5"][vc_widget_sidebar sidebar_id="cars-sidebar"][/vc_column][vc_column width="3/4" el_class="col-sm2-7"][st_cars_content_search st_style="1"][/vc_column][/vc_row]');
?>
