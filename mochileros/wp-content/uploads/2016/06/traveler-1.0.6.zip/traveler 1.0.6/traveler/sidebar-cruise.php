<?php
/**
 * @package WordPress
 * @subpackage Traveler
 * @since 1.0
 *
 * sidebar cruise
 *
 * Created by ShineTheme
 *
 */
?>
<div class="col-sm-3">
<?php
    dynamic_sidebar('hotel-sidebar');
?>
</div>