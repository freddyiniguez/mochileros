<?php
/**
 * @package WordPress
 * @subpackage Traveler
 * @since 1.0
 *
 * sidebar hotel
 *
 * Created by ShineTheme
 *
 */
?>
<div class="col-md-3 col-sm-5 ">
<?php
    dynamic_sidebar('hotel-sidebar');
?>
</div>