<?php
/**
 * @package WordPress
 * @subpackage Traveler
 * @since 1.0
 *
 * sidebar cars
 *
 * Created by ShineTheme
 *
 */
?>
<div class="col-sm-3">
<?php
    dynamic_sidebar('cars-sidebar');
?>
</div>