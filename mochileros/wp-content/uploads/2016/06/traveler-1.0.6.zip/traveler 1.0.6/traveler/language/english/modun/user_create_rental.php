<?php
// User create cruise
$lang['user_create_rental'] = __('Create rental','traveler');
$lang['user_create_rental_title'] = __('Title','traveler');
$lang['user_create_rental_content'] = __('Content','traveler');
$lang['user_create_rental_description'] = __('Description','traveler');

$lang['user_create_rental_featured_image'] = __('Featured Image','traveler');
$lang['user_create_rental_detail'] = __('Rental Detail','traveler');
$lang['user_create_rental_attributes'] = __('Attributes','traveler');
$lang['user_create_rental_email'] = __('Rental Email','traveler');
$lang['user_create_rental_website'] = __('Rental Website','traveler');
$lang['user_create_rental_phone'] = __('Rental Phone','traveler');
$lang['user_create_rental_video'] = __('Video','traveler');
$lang['user_create_rental_features'] = __('Features','traveler');
$lang['user_create_rental_add_features'] = __('Add Features','traveler');

$lang['user_create_rental_search'] = __('Search','traveler');
$lang['user_create_rental_location'] = __('Location','traveler');
$lang['user_create_rental_address'] = __('Address','traveler');
$lang['user_create_rental_latitude'] = __('Latitude','traveler');
$lang['user_create_rental_longitude'] = __('Longitude','traveler');
$lang['user_create_rental_map_zoom'] = __('Map Zoom','traveler');
$lang['user_create_rental_price'] = __('Price','traveler');
$lang['user_create_rental_discount'] = __('Discount','traveler');

$lang['user_create_rental_gallery'] = __('Gallery','traveler');
$lang['user_create_rental_submit'] = __('SUBMIT','traveler');

$lang['user_create_rental_features_title'] = __('Title','traveler');
$lang['user_create_rental_features_number'] = __('Number','traveler');
$lang['user_create_rental_features_icon'] = __('Icon','traveler');
$lang['user_create_rental_features_del'] = __('Del','traveler');



