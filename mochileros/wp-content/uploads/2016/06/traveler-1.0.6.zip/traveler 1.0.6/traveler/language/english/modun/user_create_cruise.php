<?php
// User create cruise
$lang['user_create_cruise'] = __('Create Cruise','traveler');
$lang['user_create_cruise_title'] = __('Title','traveler');
$lang['user_create_cruise_content'] = __('Content','traveler');
$lang['user_create_cruise_description'] = __('Description','traveler');
$lang['user_create_cruise_featured_image'] = __('Featured Image','traveler');
$lang['user_create_cruise_detail'] = __('cruise Detail','traveler');
$lang['user_create_cruise_attributes'] = __('Attributes','traveler');
$lang['user_create_cruise_number_of_children_stay_free'] = __('Number of children stay free','traveler');
$lang['user_create_cruise_email'] = __('Cruise Email','traveler');
$lang['user_create_cruise_website'] = __('Cruise Website','traveler');
$lang['user_create_cruise_phone'] = __('Cruise Phone','traveler');
$lang['user_create_cruise_fax_number'] = __('Fax Number','traveler');
$lang['user_create_cruise_video'] = __('Video','traveler');
$lang['user_create_cruise_programes'] = __('Programes','traveler');
$lang['user_create_cruise_add_program'] = __('Add Program','traveler');
$lang['user_create_cruise_location'] = __('Location','traveler');
$lang['user_create_cruise_address'] = __('Address','traveler');
$lang['user_create_cruise_latitude'] = __('Latitude','traveler');
$lang['user_create_cruise_longitude'] = __('Longitude','traveler');
$lang['user_create_cruise_map_zoom'] = __('Map Zoom','traveler');
$lang['user_create_cruise_gallery'] = __('Gallery','traveler');
$lang['user_create_cruise_submit'] = __('SUBMIT','traveler');
$lang['user_create_cruise_program_title'] = __('Title','traveler');
$lang['user_create_cruise_program_desc'] = __('Description','traveler');
$lang['user_create_cruise_del'] = __('Del','traveler');


