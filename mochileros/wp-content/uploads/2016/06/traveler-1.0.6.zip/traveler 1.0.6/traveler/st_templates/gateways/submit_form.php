<?php
/**
 * @package WordPress
 * @subpackage Traveler
 * @since 1.0
 *
 * Submit form
 *
 * Created by ShineTheme
 *
 */
?>
    <div class="text-center">
        <input class="btn btn-primary btn-st-big st_payment_gatewaw_submit" type="submit" name="st_payment_gateway[st_submit_form]" value="<?php st_the_language('submit_request')?>">
    </div>
    <div class="st-hr text-center m20" >
        <hr>
        <span class="st-or"><?php st_the_language('or') ?></span>
    </div>

