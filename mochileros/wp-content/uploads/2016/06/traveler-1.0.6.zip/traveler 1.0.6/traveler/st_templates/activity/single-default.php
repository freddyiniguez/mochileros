<?php
/**
 * @package WordPress
 * @subpackage Traveler
 * @since 1.0
 *
 * Activity single default
 *
 * Created by ShineTheme
 *
 */
?>
<style>
    .vc_custom_1420785387784{margin-top: 30px !important;}
    .vc_custom_1420784691705{margin-bottom: 10px !important;}
    .vc_custom_1420782018479{margin-bottom: 10px !important;}
    .vc_custom_1420785753299{margin-top: 30px !important;}
    .vc_custom_1420786944446{margin-bottom: 30px !important;}
    .vc_custom_1420786716878{margin-top: 30px !important;margin-bottom: 10px !important;}
</style>
<?php
echo do_shortcode('[vc_row row_fullwidth="no" parallax_class="no" bg_video="no"][vc_column width="7/12"][vc_tabs][vc_tab title="'.st_get_language('photos').'" tab_id="1418609998892-1-5" tab_icon="fa-camera"][st_activity_detail_photo style="slide"][/vc_tab][vc_tab title="'.st_get_language('on_the_map').'" tab_id="1418376646-2-22" tab_icon="fa-map-marker"][vc_column_text][st_activity_detail_map][/vc_column_text][/vc_tab][vc_tab title="'.st_get_language('video').'" tab_id="1419849113989-2-4" tab_icon="fa-youtube"][vc_column_text][st_activity_video][/vc_column_text][/vc_tab][/vc_tabs][/vc_column][vc_column width="5/12" css=".vc_custom_1420785387784{margin-top: 30px !important;}"][vc_row_inner][vc_column_inner width="1/1"][vc_column_text css=".vc_custom_1420784691705{margin-bottom: 10px !important;}"][st_activity_detail_review_summary][/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner][vc_column_inner width="1/1"][vc_column_text css=".vc_custom_1420782018479{margin-bottom: 10px !important;}"]
<h3>'.st_get_language('owner_description').'</h3>
[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner][vc_column_inner width="1/1"][vc_column_text][st_post_data field=excerpt][/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner css=".vc_custom_1420785753299{margin-top: 30px !important;}"][vc_column_inner width="1/1"][vc_column_text][st_form_book][/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row css=".vc_custom_1420786944446{margin-bottom: 30px !important;}" row_fullwidth="no" parallax_class="no" bg_video="no"][vc_column width="1/1"][vc_column_text css=".vc_custom_1420786716878{margin-top: 30px !important;margin-bottom: 10px !important;}"]
<h3>'.st_get_language('activity_reviews').'</h3>
[/vc_column_text][vc_row_inner][vc_column_inner width="2/3"][vc_column_text][st_activity_review][/vc_column_text][/vc_column_inner][vc_column_inner width="1/3"][vc_column_text][st_activity_nearby][/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]')
?>

