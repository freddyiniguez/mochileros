<?php 
 $lang['tour']=__('Tour','traveler');
 $lang['tours']=__('Tours','traveler');
 $lang['tour_date']=__('Date','traveler');
//search-form.php
 $lang['search_for_tour']=__('Search for Tour','traveler');
//filter.php
 $lang['tour_filter']=__('Filter','traveler');
 $lang['tour_filter_by']=__('Filter By','traveler');
//content-activity.php
 $lang['tour_sort']=__('Sort','traveler');
 $lang['tour_showing']=__('Showing','traveler');
 $lang['tour_not_what_you_looking_for']=__('Not what you\'re looking for? ','traveler');
 $lang['tour_try_your_search_again']=__('Try your search again','traveler');
// cart_item_html
 $lang['sorry_tour_not_found']=__('Sorry!. Tour Not Found','traveler');
 $lang['tours_information']=__('Tours information','traveler');
 $lang['tour_duration_days']=__('Duration Days','traveler');
 $lang['tour_max_people']=__('Max people','traveler');
 $lang['tour_price']=__('Price','traveler');
 $lang['tour_number']=__('Number','traveler');
 $lang['tour_total']=__('Total','traveler');
//element/price.php
 $lang['tour_price_from']=__('price from','traveler');
 $lang['tour_from']=__('from','traveler');
//element/nearby.php
 $lang['similar_tour']=__('SIMILAR TOUR','traveler');
 $lang['similar_tours']=__('SIMILAR TOUR(S)','traveler');
// info-tour.php
 $lang['tour_day']=__('day','traveler');

 $lang['tour_days']=__('days','traveler');
 $lang['tour_peoples'] = __('peoples','traveler');
 $lang['tour_people'] = __('people','traveler');
 $lang['tour_location'] = __('Location','traveler');
 $lang['tour_rate'] = __('Rate','traveler');
 $lang['tour_book_now'] = __('Book Now','traveler');
//search
 $lang['tour_duration'] = __('Duration','traveler');
 $lang['tours_or_us_zip_Code'] = __('Tours or U.S. Zip Code','traveler');
// loop 1
 $lang['tour_no_review'] = __('no review','traveler');
 $lang['tour_1_review'] = __('1 review','traveler');
 $lang['tour_reviews'] = __('reviews','traveler');
 $lang['tour_email'] = __('Tour E-mail','traveler');
 $lang['tour_website'] = __('Tour Website','traveler');
 $lang['tour_not_set_layout'] = __('Not set default layout !','traveler');
 $lang['tour_to'] = __('to ','traveler');
 $lang['tour_of_5'] = __('of 5','traveler');
 $lang['tour_you_are_booking_for_d'] = __('You are booking for %s','traveler');
 $lang['tour_last_minute_deals'] = __('LAST MINUTE DEALS!','traveler');
 $lang['tour_program'] = __('Tour"s Program','traveler');
 $lang['tour_none']=__('none','traveler');











