/*
    Theme Name: Traveler - One Page Parallax WordPress Theme
    Theme URI: http://shinetheme.com/demosd/traveler
    Author: Shine Theme
    Author URI: http://shinetheme.com
    Release Date: 10 march 2015
    Requirements: WordPress 3.8 or higher, PHP 5
    Compatibility: WordPress 4.1.1
    Tags: web app
    Last Update Date: 4th April 2015
*/



	First of all I would like to thank you for your purchase! You are the best!
	Welcome to Traveler - The Multipurpose Booking Template! Traveler is a perfect theme use as an online platform, where all types of temporary services providers, included Hotels, Rentals, Car hiring, Tour and Activities programs... can advertise their services for reservation, and where visitors to the website can make such reservations. Generated ideas from various popular travel booking websites such as booking.com, tripadvisor, yahoo travel, expedia, priceline, hotels.com, travelocity, kayak, orbitz..., Traveler has almost all features that you will ever need, with eye-catching design, quality codes and supportive services. All though amazing features are brought together in only one template by Shinetheme Team. So, let's enjoy it!
 
	Before getting started, however, please check through this document first for Traveler's installation and using guides. If there is any further problem that our document could not cover, please search from our Knowledgebase, check our Tutorial Videos, and do a Forum Search. Probably your question or issue have already been brought up and the answer is waiting to be found. You can also create a new topic with all the details related to your problem (Remember to include your site's URL as well). We will try as best as possible to help you solve the problem. Thank you.
	
	With all our sincerities, we wish you an wonderful experience with Traveler!

/*--------- What’s Included -------------------------------------------------------------------------------*/

-  This package contains:
+ traveler.zip: theme version 1.0.4, Upload this file to install theme.
+ traveler-child.zip: Child theme for traveler.
+ traveler_documentation: Document Offline for traveler. You can view documentation Online here: http://shinetheme.com/demosd/doc/traveler
+ VisualComposer_documentation: How to use visual composer to build this template?  
 Using Visual Composer is very straight forward process, most accurate documentation is always available in the WPBakery Knowledge Base site:
   http://kb.wpbakery.com/index.php?title=Visual_Composer

   Offline documentation is also available. To view it, navigate to the documentation folder and double click start.html file.

+ Datademo: 
    - data_demo/demo_data.xml: You can use file when you choose the way Import All Demo Content With file XML
	 
   
   
   
/*-------------------------------------------------------------------------------*/
   
 
Thanks for your choice!!